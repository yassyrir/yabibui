module.exports = {
  tokens: "8431390017:AAH3tixXVCbIJu1CekpDKS1tHvFulPSXOJw",  // Masukin Bot token kamu
  owners: "8331794302", // Masukin ID Telegram kamu
  port: "2256", // Masukin Port panel kamu 
  ipvps: "http://genxzbaikxhati.publictirzx.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};